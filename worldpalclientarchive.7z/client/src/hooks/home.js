//display the text of home.

import React from 'react'

const Home = props => (
    <div>
      Home
    </div>
);

export default Home;