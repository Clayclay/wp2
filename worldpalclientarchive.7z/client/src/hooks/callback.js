//will be used as the component that Auth0 will redirect to 
//after the user authenticates( logging).

import React from 'react'

const Callback = props => (
    <div>
      Callback
    </div>
);
// From here the user is redirected to the authcheck page then the home page
export default Callback;