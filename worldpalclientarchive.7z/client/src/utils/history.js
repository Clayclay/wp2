//Will hold the history object which we will use for navigation.

import { createBrowserHistory } from 'history'

export default createBrowserHistory()